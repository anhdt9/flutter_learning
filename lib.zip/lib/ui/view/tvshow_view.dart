import 'package:flutter/material.dart';

class TvShowView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.green,
      child: Center(
        child: Text("TvShowView"),
      ),
    );
  }
}
